'use strict';

export const GlobalVariable = Object.freeze({
    BASE_API_URL: 'http://termsoflife.com/api_v1/index.php/api/',
    //... more of your variables
});
