import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions,Response } from '@angular/http';
import { Subject, ReplaySubject } from 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do'; 
import 'rxjs/add/operator/catch'; 

@Injectable()
export class CommonServiceService {

  constructor(private _http:Http){
  }
  
  
  list(url){
    return this._http.get(url)
    .map(res=>{
      return res.json()
    });    
 }

}
