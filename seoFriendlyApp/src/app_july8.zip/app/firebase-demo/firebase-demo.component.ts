import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firebase-demo',
  templateUrl: './firebase-demo.component.html',
  styleUrls: ['./firebase-demo.component.css']
})
export class FirebaseDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
