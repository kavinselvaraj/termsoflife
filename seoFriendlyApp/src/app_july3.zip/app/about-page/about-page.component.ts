import { Component, OnInit } from '@angular/core';
import { SeoService } from '../seo.service';
import { GlobalVariable } from '../global.service';
import { CommonServiceService } from '../common-service.service';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {NgxPaginationModule} from 'ngx-pagination';
import { element } from 'protractor';

@Component({
  selector: 'app-about-page',
  templateUrl: './about-page.component.html',
  styleUrls: ['./about-page.component.css']
  
})
export class AboutPageComponent implements OnInit {
  p: number = 1;
blogdetails:any;
singdetails:any;
previous:any;
feature_post=[];
feature_post1=[];
img_path : string ="http://termsoflife.com/api_v1/upload/";
blogs:any;
collection = [];
public blog_ban =  GlobalVariable.BASE_API_URL+"Homebanner/blogbanner";
  constructor(private seo: SeoService, 
    private _service:CommonServiceService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  public get_details_page=GlobalVariable.BASE_API_URL+"blog/getcategoryblogs";
  
  id = 'first_blog_seo';
  category = 'second';
  ngOnInit() {
    this._service.list(this.blog_ban).subscribe(blogdetails =>{
      this.blogdetails = blogdetails;
      console.log(this.blogdetails)
    })
    this.getDetailpage();
  }
  getDetailpage()
  {
  
    this._service.
    list(this.get_details_page+'?category=May1').subscribe(singdetails =>{
      this.singdetails = singdetails.full;
      this.feature_post = singdetails.sub;
     

      for(var key in this.feature_post){
        if(this.feature_post[key].blog.length > 0){
          this.feature_post1.push(this.feature_post[key]);
        }
        for(var key1 in this.feature_post[key].blog){
          //console.log(this.feature_post[key].blog[key1])
          this.collection.push(this.feature_post[key].blog[key1]);
        }
      }
      
      console.log(this.singdetails);
      console.log(this.feature_post1);
    })
  
  }


}
